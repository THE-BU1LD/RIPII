"""Replay the retained valid-input tensors against original and repaired source.

Run from the RIPII Git checkout containing the repair. The original class is loaded
from the recorded commit; its project dependencies must still match that commit.
Only tensor/state-dict payloads are loaded, with weights_only=True.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path

import torch

from ripii.world.models import WorldModel

BASE = "33b799fb3bb0d5215e954c5f80d2225c51a5caaa"


def historical_source(path: str) -> bytes:
    return subprocess.check_output(["git", "show", f"{BASE}:{path}"])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("snapshot", type=Path)
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    source_path = "ripii/world/models.py"
    original = historical_source(source_path)
    dependencies = {}
    for path in ("ripii/world/multiresolution.py", "ripii/models/quantizer.py"):
        content = Path(path).read_bytes()
        if content != historical_source(path):
            raise ValueError(f"baseline dependency changed: {path}")
        dependencies[path] = hashlib.sha256(content).hexdigest()
    namespace = {
        "__name__": "ripii.world._baseline_contract",
        "__package__": "ripii.world",
    }
    exec(compile(original, f"{BASE}:{source_path}", "exec"), namespace)
    baseline_model = namespace["WorldModel"]
    payload = torch.load(args.snapshot, map_location="cpu", weights_only=True)
    rows = []
    for variant, retained in payload["variants"].items():
        for label, constructor in (
            ("original", baseline_model),
            ("repaired", WorldModel),
        ):
            model = constructor(variant, hidden=16)
            model.load_state_dict(retained["parameters"])
            prediction = model(payload["state"], payload["action"], payload["mask"])
            prediction[..., :4].square().mean().backward()
            gradients = {
                name: parameter.grad
                for name, parameter in model.named_parameters()
                if parameter.grad is not None
            }
            row = {
                "source": label,
                "variant": variant,
                "predictions_bitwise_equal_to_retained": torch.equal(
                    prediction, retained["output"]
                ),
                "gradient_keys_equal": gradients.keys() == retained["gradients"].keys(),
                "gradient_tensors": len(gradients),
                "gradients_bitwise_equal_to_retained": all(
                    torch.equal(value, retained["gradients"][name])
                    for name, value in gradients.items()
                ),
            }
            if not all(
                row[key]
                for key in (
                    "predictions_bitwise_equal_to_retained",
                    "gradient_keys_equal",
                    "gradients_bitwise_equal_to_retained",
                )
            ):
                raise AssertionError(row)
            rows.append(row)
    print(
        json.dumps(
            {
                "status": "PASS",
                "baseline_commit": BASE,
                "baseline_models_sha256": hashlib.sha256(original).hexdigest(),
                "repaired_models_sha256": hashlib.sha256(
                    Path(source_path).read_bytes()
                ).hexdigest(),
                "shared_dependency_sha256": dependencies,
                "snapshot_sha256": hashlib.sha256(
                    args.snapshot.read_bytes()
                ).hexdigest(),
                "loss": "prediction[..., :4].square().mean()",
                "environment": {
                    "torch": str(torch.__version__),
                    "device": "cpu",
                    "torch_threads": 1,
                },
                "boundary": "One retained four-scene float32 fixture and disclosed untrained parameters per variant; no runtime equivalence or population claim.",
                "comparisons": rows,
            },
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
